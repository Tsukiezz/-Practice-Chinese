import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Pressable } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Chinese Learning</Text>
      <Text style={styles.subtitle}>Ứng dụng hỗ trợ học tiếng Trung</Text>
      <Pressable style={styles.button}>
        <Text style={styles.buttonText}>Bắt đầu học</Text>
      </Pressable>
      <Text style={styles.note}>MVP – giao diện khởi tạo</Text>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  title: { fontSize: 30, fontWeight: '700', marginBottom: 8 },
  subtitle: { fontSize: 16, textAlign: 'center', marginBottom: 24 },
  button: { paddingHorizontal: 24, paddingVertical: 14, borderRadius: 10, backgroundColor: '#2563eb' },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  note: { marginTop: 24, color: '#666' }
});
