# Test Plan

Module: Authentication, Course, Lesson, Vocabulary, Quiz, Progress, Profile, Admin, AI.

Bug flow: Open -> In Progress -> Fixed -> Retest -> Passed.
Nếu retest thất bại: Failed -> Reopen.
