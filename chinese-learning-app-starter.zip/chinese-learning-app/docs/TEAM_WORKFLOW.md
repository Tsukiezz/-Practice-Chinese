# Team Workflow

- main: bản ổn định
- develop: tích hợp
- feature/*: từng chức năng

Không push trực tiếp vào main. Mỗi chức năng tạo feature branch, test, push và tạo Pull Request.

Commit convention:
- feat: chức năng mới
- fix: sửa lỗi
- refactor: cải tổ code
- test: kiểm thử
- docs: tài liệu
- chore: cấu hình

Ví dụ: feat: add login API
