# AI Plan

AI triển khai sau khi MVP ổn định.

1. AI Tutor: hỏi đáp kiến thức tiếng Trung.
2. AI Explain: giải thích từ vựng/ngữ pháp.
3. AI Recommendation: đề xuất học dựa trên progress và quiz result.

Kiến trúc: Mobile -> Backend -> AI Service -> AI Model/API.

Không để API key AI trong mobile app.

API dự kiến:
POST /api/ai/chat
POST /api/ai/explain
POST /api/ai/recommend
