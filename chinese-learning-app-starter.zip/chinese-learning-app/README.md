# Chinese Learning App

Đồ án môn học – CNTT, chuyên ngành Hệ thống thông tin.

## Thành viên
1. Phạm Văn Tuyến – Project Manager + Business Analyst
2. Nguyễn Thành Trung – Backend Developer
3. Phạm Thị Tường Vy – Frontend Developer (Mobile UI)
4. Phan Tuấn Kiệt – Full-stack Support / Integration
5. Nguyễn Võ Vĩnh Nguyên – Tester + Documentation / Repository Leader

## Stack
- Mobile: React Native + Expo
- Backend: Node.js + Express
- Database: MySQL
- API test: Postman
- Version control: Git + GitHub
- AI: tích hợp sau khi MVP ổn định

## Cấu trúc
```text
chinese-learning-app/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   ├── controllers/
│   │   ├── middleware/
│   │   ├── routes/
│   │   └── services/
│   ├── .env.example
│   └── package.json
├── mobile/
├── database/
├── docs/
├── .gitignore
└── README.md
```

## Git workflow
- `main`: bản ổn định
- `develop`: tích hợp
- `feature/*`: từng chức năng
- Không push trực tiếp vào `main`.

## Backend
```bash
cd backend
npm install
copy .env.example .env
npm run dev
```
Health check: `http://localhost:5000/api/health`

## Mobile
```bash
cd mobile
npm install
npx expo start
```
